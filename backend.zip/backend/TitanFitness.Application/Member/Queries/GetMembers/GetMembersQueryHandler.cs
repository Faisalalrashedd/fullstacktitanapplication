﻿
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using TitanFitness.Application.Interfaces;
using TitanFitness.Application.Members.Dtos;
using MemberEntity = TitanFitness.Domain.Entities.Member;

namespace TitanFitness.Application.Members.Queries.GetMembers
{
    public class PagedMembersResult
    {
        public List<MemberDto> Items { get; set; } = new();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
    }

    public class GetMembersQueryHandler
    {
        private readonly IGenericRepository<MemberEntity> _memberRepository;

        public GetMembersQueryHandler(
            IGenericRepository<MemberEntity> memberRepository)
        {
            _memberRepository = memberRepository;
        }

        private static MemberDto ToDto(MemberEntity member)
        {
            return new MemberDto
            {
                MemberId = member.MemberId,
                MembershipNumber = member.MembershipNumber,
                FullName = member.FullName,
                Email = member.Email,
                Phone = member.Phone,
                Address = member.Address,
                JoinedDate = member.JoinedDate,
                Photo = member.Photo,
                HomeBranchId = member.HomeBranchId
            };
        }

        public async Task<List<MemberDto>> Handle(GetMembersQuery query)
        {
            var members = await _memberRepository.GetAllAsync();

            return members.Select(ToDto).ToList();
        }

        public async Task<PagedMembersResult> HandlePaged(
            int page,
            int pageSize,
            string? search,
            int branchId,
            string sort,
            string direction)
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, 100);

            var searchText = search?.Trim() ?? "";

            System.Linq.Expressions.Expression<
                Func<MemberEntity, bool>> filter = member =>
                (branchId == 0 || member.HomeBranchId == branchId) &&
                (
                    searchText == "" ||
                    member.FullName.Contains(searchText) ||
                    member.MembershipNumber.Contains(searchText)
                );

            string orderProperty = sort switch
            {
                "memberId" => "MembershipNumber",
                "branch" => "HomeBranchId",
                _ => "FullName"
            };

            bool descending = direction == "desc";

            var result = await _memberRepository.GetPagedAsync(
                page,
                pageSize,
                filter,
                orderProperty,
                descending
            );

            return new PagedMembersResult
            {
                Items = result.Items.Select(ToDto).ToList(),
                TotalCount = result.TotalCount,
                Page = page,
                PageSize = pageSize
            };
        }
    }
}

﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TitanFitness.Domain.Enums;
using TitanFitness.Infrastructure.Persistence;

namespace TitanFitness.API.Controllers
{
    [ApiController]
    [Route("api/Members/directory-details")]
    public class MemberDirectoryDetailsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public MemberDirectoryDetailsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetDetails(
            [FromQuery] int[] ids)
        {
            if (ids.Length == 0)
            {
                return Ok(Array.Empty<object>());
            }

            if (ids.Length > 100 || ids.Any(id => id <= 0))
            {
                return BadRequest(new
                {
                    message = "Provide up to 100 valid member IDs."
                });
            }

            var memberIds = ids.Distinct().ToArray();
            var today = DateOnly.FromDateTime(DateTime.Today);

            var memberships = await _context.Memberships
                .AsNoTracking()
                .Where(x => memberIds.Contains(x.MemberId))
                .Select(x => new
                {
                    x.MemberId,
                    x.MembershipId,
                    x.StartDate,
                    x.EndDate,
                    x.Status
                })
                .ToListAsync();

            var visits = await _context.CheckIns
                .AsNoTracking()
                .Where(x =>
                    memberIds.Contains(x.MemberId) &&
                    x.Result == CheckInResult.Admitted)
                .GroupBy(x => x.MemberId)
                .Select(g => new
                {
                    MemberId = g.Key,
                    LastVisit = g.Max(x => x.CheckInDateTime)
                })
                .ToListAsync();

            var results = memberIds.Select(id =>
            {
                var history = memberships
                    .Where(x => x.MemberId == id)
                    .OrderByDescending(x => x.StartDate)
                    .ToList();

                var current = history.FirstOrDefault(x =>
                    x.Status == MembershipStatus.Active &&
                    x.StartDate <= today &&
                    x.EndDate >= today)
                    ?? history.FirstOrDefault(x =>
                        x.Status == MembershipStatus.Frozen)
                    ?? history.FirstOrDefault();

                string status;

                if (current == null)
                {
                    status = "No Membership";
                }
                else if (current.Status == MembershipStatus.Cancelled)
                {
                    status = "Cancelled";
                }
                else if (current.Status == MembershipStatus.Frozen)
                {
                    status = "Frozen";
                }
                else if (current.EndDate < today)
                {
                    status = "Expired";
                }
                else if (current.Status == MembershipStatus.Active &&
                         current.StartDate <= today)
                {
                    status = "Active";
                }
                else
                {
                    status = "Pending";
                }

                var visit = visits.FirstOrDefault(x => x.MemberId == id);

                return new
                {
                    memberId = id,
                    status,
                    lastVisit = visit?.LastVisit
                };
            });

            return Ok(results);
        }
    }
}

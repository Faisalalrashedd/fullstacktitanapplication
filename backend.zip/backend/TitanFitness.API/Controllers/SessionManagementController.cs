﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TitanFitness.Domain.Enums;
using TitanFitness.Infrastructure.Persistence;

namespace TitanFitness.API.Controllers
{
    public class UpdateSessionRequest
    {
        public string ClassName { get; set; } = "";
        public int BranchId { get; set; }
        public int StudioId { get; set; }
        public int TrainerId { get; set; }
        public DateOnly SessionDate { get; set; }
        public TimeOnly StartTime { get; set; }
        public int DurationInMinutes { get; set; }
        public int CapacityLimit { get; set; }
        public string? Description { get; set; }
    }

    [ApiController]
    [Route("api/Sessions")]
    public class SessionManagementController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SessionManagementController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var session = await _context.ClassSessions
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.SessionId == id);

            if (session == null)
                return NotFound(new { message = "Class not found" });

            return Ok(new
            {
                session.SessionId,
                session.ClassName,
                session.BranchId,
                session.StudioId,
                session.TrainerId,
                session.SessionDate,
                session.StartTime,
                session.DurationInMinutes,
                session.CapacityLimit,
                session.Status,
                session.Description
            });
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(
            int id,
            UpdateSessionRequest request)
        {
            var session = await _context.ClassSessions
                .FirstOrDefaultAsync(x => x.SessionId == id);

            if (session == null)
                return NotFound(new { message = "Class not found" });

            if (session.Status == SessionStatus.Cancelled ||
                session.Status == SessionStatus.Completed)
            {
                return BadRequest(new
                {
                    message = "Cancelled or completed classes cannot be edited"
                });
            }

            if (string.IsNullOrWhiteSpace(request.ClassName) ||
                request.BranchId <= 0 ||
                request.StudioId <= 0 ||
                request.TrainerId <= 0 ||
                request.DurationInMinutes <= 0 ||
                request.CapacityLimit <= 0 ||
                request.SessionDate == default)
            {
                return BadRequest(new
                {
                    message = "Enter all required class details"
                });
            }

            var branchExists = await _context.Branches
                .AnyAsync(x => x.BranchId == request.BranchId);

            if (!branchExists)
                return BadRequest(new { message = "Invalid branch" });

            var studioExists = await _context.Studios
                .AnyAsync(x =>
                    x.StudioId == request.StudioId &&
                    x.BranchId == request.BranchId);

            if (!studioExists)
                return BadRequest(new
                {
                    message = "Studio does not belong to the selected branch"
                });

            var trainerExists = await _context.Trainers
                .AnyAsync(x =>
                    x.TrainerId == request.TrainerId &&
                    x.IsActive);

            if (!trainerExists)
                return BadRequest(new { message = "Select an active trainer" });

            var bookingCount = await _context.Bookings
                .CountAsync(x => x.SessionId == id);

            if (request.CapacityLimit < bookingCount)
            {
                return BadRequest(new
                {
                    message = "Capacity cannot be less than existing bookings"
                });
            }

            var proposedEnd = request.StartTime
                .AddMinutes(request.DurationInMinutes);

            var conflict = await _context.ClassSessions
                .AnyAsync(x =>
                    x.SessionId != id &&
                    x.SessionDate == request.SessionDate &&
                    x.Status != SessionStatus.Cancelled &&
                    (
                        x.StudioId == request.StudioId ||
                        x.TrainerId == request.TrainerId
                    ) &&
                    x.StartTime < proposedEnd &&
                    request.StartTime <
                        x.StartTime.AddMinutes(x.DurationInMinutes));

            if (conflict)
            {
                return BadRequest(new
                {
                    message = "Trainer or studio is already booked at this time"
                });
            }

            session.ClassName = request.ClassName.Trim();
            session.BranchId = request.BranchId;
            session.StudioId = request.StudioId;
            session.TrainerId = request.TrainerId;
            session.SessionDate = request.SessionDate;
            session.StartTime = request.StartTime;
            session.DurationInMinutes = request.DurationInMinutes;
            session.CapacityLimit = request.CapacityLimit;
            session.Description = request.Description?.Trim();

            await _context.SaveChangesAsync();

            return Ok(new { message = "Class updated successfully" });
        }

        [HttpPatch("{id:int}/cancel")]
        public async Task<IActionResult> Cancel(int id)
        {
            var session = await _context.ClassSessions
                .FirstOrDefaultAsync(x => x.SessionId == id);

            if (session == null)
                return NotFound(new { message = "Class not found" });

            if (session.Status == SessionStatus.Completed)
            {
                return BadRequest(new
                {
                    message = "Completed classes cannot be cancelled"
                });
            }

            if (session.Status == SessionStatus.Cancelled)
            {
                return BadRequest(new
                {
                    message = "Class is already cancelled"
                });
            }

            session.Status = SessionStatus.Cancelled;

            await _context.SaveChangesAsync();

            return Ok(new { message = "Class cancelled successfully" });
        }
    }
}

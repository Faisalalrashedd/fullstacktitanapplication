
import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { catchError, throwError } from 'rxjs';

export const apiErrorInterceptor: HttpInterceptorFn = (req, next) => {
  const snackBar = inject(MatSnackBar);

  const token = sessionStorage.getItem('authToken');

  const request = token
    ? req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      })
    : req;

  return next(request).pipe(
    catchError((error: HttpErrorResponse) => {
      let message = '';

      switch (error.status) {
        case 0:
          message = "Can't reach the server. Check your connection.";
          break;

        case 400:
          message = 'Invalid request. Check the entered information.';
          break;

        case 401:
          sessionStorage.removeItem('authToken');
          message = 'Your session has expired.';
          break;

        case 403:
          message = "You don't have permission to do this.";
          break;

        case 404:
          message = 'The requested item was not found.';
          break;

        case 409:
          message = error.error?.message || 'This record already exists or was changed.';
          break;

        case 422:
          message = 'Validation failed. Check the form fields.';
          break;

        default:
          if (error.status >= 500) {
            message = 'Something went wrong. Please try again.';
          }
          break;
      }

      if (message) {
        snackBar.open(message, 'Close', {
          duration: 5000,
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
      }

      return throwError(() => error);
    })
  );
};

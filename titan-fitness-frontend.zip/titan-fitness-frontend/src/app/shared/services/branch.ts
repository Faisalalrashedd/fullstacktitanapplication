import { effect, Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BranchService {
  currentBranch = signal('Downtown');

  constructor() {
    effect(() => {
      localStorage.setItem(
        'currentBranch',
        this.currentBranch()
      );
    });
  }

  setBranch(branch: string): void {
    this.currentBranch.set(branch);
  }
}
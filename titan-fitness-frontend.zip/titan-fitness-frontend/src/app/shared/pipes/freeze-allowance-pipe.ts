import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'freezeAllowance',
  standalone: true,
  pure: true
})
export class FreezeAllowancePipe implements PipeTransform {
  transform(days: number, freezes: number): string {
    if (days === 0 || freezes === 0) {
      return 'None';
    }

    return `${days} days / ${freezes} freezes`;
  }
}
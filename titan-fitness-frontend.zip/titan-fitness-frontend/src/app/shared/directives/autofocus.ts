import {
  Directive,
  ElementRef,
  inject
} from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Directive({
  selector: '[appAutofocus]',
  standalone: true
})
export class Autofocus {
  private element = inject(ElementRef<HTMLInputElement>);
  private dialogRef = inject(MatDialogRef, { optional: true });

  constructor() {
    if (this.dialogRef) {
      this.dialogRef.afterOpened().subscribe(() => {
        this.element.nativeElement.focus();
      });
    }
  }
}
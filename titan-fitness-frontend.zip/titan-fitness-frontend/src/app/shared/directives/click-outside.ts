import {
  Directive,
  ElementRef,
  HostListener,
  output
} from '@angular/core';

@Directive({
  selector: '[appClickOutside]',
  standalone: true
})
export class ClickOutside {
  clickedOutside = output<void>();

  constructor(
    private element: ElementRef<HTMLElement>
  ) {}

  @HostListener('document:mousedown', ['$event'])
  onDocumentMouseDown(event: MouseEvent): void {
    const target = event.target as Node;

    if (!this.element.nativeElement.contains(target)) {
      this.clickedOutside.emit();
    }
  }
}
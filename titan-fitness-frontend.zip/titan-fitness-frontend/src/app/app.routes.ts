import { Routes } from '@angular/router';
import { Shell } from './layout/shell/shell';

export const routes: Routes = [
  {
    path: '',
    component: Shell,
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/pages/dashboard/dashboard')
            .then(m => m.Dashboard)
      },
      {
  path: 'members/:id',
  loadComponent: () =>
    import('./features/members/pages/member-profile/member-profile')
      .then(m => m.MemberProfile)
      },
      {
  path: 'members/:id/freeze',
  loadComponent: () =>
    import('./features/members/pages/freeze-membership/freeze-membership')
      .then(m => m.FreezeMembership)
      },
      {
        path: 'members',
        loadComponent: () =>
          import('./features/members/pages/member-directory/member-directory')
            .then(m => m.MemberDirectory)
      },
      {
        path: 'classes',
        loadComponent: () =>
          import('./features/classes/pages/class-schedule/class-schedule')
            .then(m => m.ClassSchedule)
      },
      {
        path: 'trainers/new',
        loadComponent: () =>
            import('./features/trainers/pages/trainer-details/trainer-details')
            .then(m => m.TrainerDetails)
        },
        {
        path: 'trainers/:id/edit',
        loadComponent: () =>
            import('./features/trainers/pages/trainer-details/trainer-details')
            .then(m => m.TrainerDetails)
        },
        {
        path: 'trainers/:id',
        loadComponent: () =>
            import('./features/trainers/pages/trainer-details/trainer-details')
            .then(m => m.TrainerDetails)
        },
        {
        path: 'trainers',
        loadComponent: () =>
            import('./features/trainers/pages/trainer-directory/trainer-directory')
            .then(m => m.TrainerDirectory)
        },
      {
        path: 'trainers',
        loadComponent: () =>
          import('./features/trainers/pages/trainer-directory/trainer-directory')
            .then(m => m.TrainerDirectory)
      },{
        path: 'plans/new',
        loadComponent: () =>
            import('./features/plans/pages/plan-details/plan-details')
            .then(m => m.PlanDetails)
        },
        {
        path: 'plans/:id/edit',
        loadComponent: () =>
            import('./features/plans/pages/plan-details/plan-details')
            .then(m => m.PlanDetails)
        },
        {
        path: 'plans/:id',
        loadComponent: () =>
            import('./features/plans/pages/plan-details/plan-details')
            .then(m => m.PlanDetails)
        },
        {
        path: 'plans',
        loadComponent: () =>
            import('./features/plans/pages/plan-catalogue/plan-catalogue')
            .then(m => m.PlanCatalogue)
        },
      {
        path: 'plans',
        loadComponent: () =>
          import('./features/plans/pages/plan-catalogue/plan-catalogue')
            .then(m => m.PlanCatalogue)
      }
    ]
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];
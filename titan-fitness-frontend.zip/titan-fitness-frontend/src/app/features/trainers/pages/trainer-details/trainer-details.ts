
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { TrainerService, SaveTrainerDto } from '../../services/trainer';

type TrainerMode = 'add' | 'view' | 'edit';

@Component({
  selector: 'app-trainer-details',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './trainer-details.html',
  styleUrl: './trainer-details.css'
})
export class TrainerDetails implements OnInit {
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private trainerService = inject(TrainerService);

  mode = signal<TrainerMode>('view');
  trainerId = signal<number | null>(null);
  trainerName = signal('Trainer Details');

  loading = signal(false);
  saving = signal(false);
  errorMessage = signal('');

  isViewMode = computed(() => this.mode() === 'view');
  isAddMode = computed(() => this.mode() === 'add');
  isEditMode = computed(() => this.mode() === 'edit');

  pageTitle = computed(() =>
    this.isAddMode() ? 'New Trainer' : this.trainerName()
  );

  modeText = computed(() => {
    if (this.isAddMode()) return 'Add mode';
    if (this.isEditMode()) return 'Update mode';
    return 'View mode';
  });

  form = this.fb.group({
    name: ['', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(80)
    ]],
    specialty: [''],
    branch: [''],
    email: ['', [
      Validators.required,
      Validators.email
    ]],
    phone: [''],
    isActive: [true]
  });

  ngOnInit(): void {
    const url = this.router.url;

    if (url === '/trainers/new') {
      this.mode.set('add');
      return;
    }

    const id = Number(this.route.snapshot.paramMap.get('id'));

    if (!Number.isInteger(id) || id <= 0) {
      this.errorMessage.set('Invalid trainer ID.');
      return;
    }

    this.trainerId.set(id);
    this.mode.set(url.endsWith('/edit') ? 'edit' : 'view');
    this.loadTrainer(id);
  }

  loadTrainer(id: number): void {
    this.loading.set(true);
    this.errorMessage.set('');

    this.trainerService.getTrainer(id).subscribe({
      next: trainer => {
        this.trainerName.set(trainer.trainerName);

        this.form.patchValue({
          name: trainer.trainerName,
          specialty: '',
          branch: '',
          email: trainer.email || '',
          phone: trainer.phone || '',
          isActive: trainer.isActive
        });

        if (this.isViewMode()) {
          this.form.disable();
        } else {
          this.form.enable();
        }

        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load trainer:', error);
        this.errorMessage.set(
          error.status === 404
            ? 'Trainer not found.'
            : 'Failed to load trainer.'
        );
        this.loading.set(false);
      }
    });
  }

  editTrainer(): void {
    const id = this.trainerId();

    if (id !== null) {
      this.router.navigate(['/trainers', id, 'edit']);
    }
  }

  cancel(): void {
    const id = this.trainerId();

    if (this.isEditMode() && id !== null) {
      this.router.navigate(['/trainers', id]);
    } else {
      this.router.navigate(['/trainers']);
    }
  }

  save(): void {
    if (this.form.invalid || this.saving()) {
      this.form.markAllAsTouched();
      return;
    }

    const values = this.form.getRawValue();

    const request: SaveTrainerDto = {
      trainerName: values.name?.trim() || '',
      email: values.email?.trim() || null,
      phone: values.phone?.trim() || null,
      isActive: values.isActive ?? true
    };

    this.saving.set(true);
    this.errorMessage.set('');

    if (this.isAddMode()) {
      this.trainerService.addTrainer(request).subscribe({
        next: result => {
          this.saving.set(false);
          alert('Trainer created successfully');

          if (result.trainerId) {
            this.router.navigate(['/trainers', result.trainerId]);
          } else {
            this.router.navigate(['/trainers']);
          }
        },
        error: error => {
          console.error('Failed to create trainer:', error);
          this.errorMessage.set('Failed to create trainer.');
          this.saving.set(false);
        }
      });

      return;
    }

    const id = this.trainerId();

    if (id === null) {
      this.saving.set(false);
      return;
    }

    this.trainerService.updateTrainer(id, request).subscribe({
      next: () => {
        this.saving.set(false);
        alert('Trainer updated successfully');
        this.router.navigate(['/trainers', id]);
      },
      error: error => {
        console.error('Failed to update trainer:', error);
        this.errorMessage.set('Failed to update trainer.');
        this.saving.set(false);
      }
    });
  }
}

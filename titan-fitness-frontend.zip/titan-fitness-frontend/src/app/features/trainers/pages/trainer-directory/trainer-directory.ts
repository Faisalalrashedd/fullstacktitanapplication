
import { Component, computed, signal, inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';

import { StatusBadge } from '../../../../shared/components/status-badge/status-badge';
import { Paginator } from '../../../../shared/components/paginator/paginator';
import { HighlightPipe } from '../../../../shared/pipes/highlight-pipe';
import { TrainerService } from '../../services/trainer';

interface Trainer {
  id: number;
  trainerId: string;
  name: string;
  initials: string;
  specialty: string;
  branch: string;
  status: 'Active' | 'Inactive';
}

@Component({
  selector: 'app-trainer-directory',
  standalone: true,
  imports: [
    RouterLink,
    StatusBadge,
    Paginator,
    HighlightPipe
  ],
  templateUrl: './trainer-directory.html',
  styleUrl: './trainer-directory.css'
})
export class TrainerDirectory implements OnInit {
  private trainerService = inject(TrainerService);

  searchTerm = signal('');
  currentPage = signal(1);
  pageSize = 4;
  openMenuId = signal<number | null>(null);

  loading = signal(false);
  errorMessage = signal('');

  trainers = signal<Trainer[]>([]);

  filteredTrainers = computed(() => {
    const search = this.searchTerm().trim().toLowerCase();

    if (!search) {
      return this.trainers();
    }

    return this.trainers().filter(trainer =>
      trainer.name.toLowerCase().includes(search) ||
      trainer.trainerId.toLowerCase().includes(search) ||
      trainer.specialty.toLowerCase().includes(search)
    );
  });

  totalPages = computed(() =>
    Math.max(
      1,
      Math.ceil(this.filteredTrainers().length / this.pageSize)
    )
  );

  pagedTrainers = computed(() => {
    const start = (this.currentPage() - 1) * this.pageSize;

    return this.filteredTrainers().slice(
      start,
      start + this.pageSize
    );
  });

  ngOnInit(): void {
    this.loadTrainers();
  }

  loadTrainers(): void {
    this.loading.set(true);
    this.errorMessage.set('');

    this.trainerService.getTrainers().subscribe({
      next: trainers => {
        const mappedTrainers: Trainer[] = trainers.map(trainer => ({
          id: trainer.trainerId,
          trainerId: `TR-${trainer.trainerId}`,
          name: trainer.trainerName,
          initials: trainer.trainerName
            .trim()
            .split(/\s+/)
            .filter(Boolean)
            .slice(0, 2)
            .map(part => part.charAt(0).toUpperCase())
            .join(''),
          specialty: 'Not assigned',
          branch: 'Not assigned',
          status: trainer.isActive ? 'Active' : 'Inactive'
        }));

        this.trainers.set(mappedTrainers);
        this.currentPage.set(1);
        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load trainers:', error);
        this.errorMessage.set('Failed to load trainers.');
        this.loading.set(false);
      }
    });
  }

  updateSearch(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.searchTerm.set(input.value);
    this.currentPage.set(1);
    this.openMenuId.set(null);
  }

  changePage(page: number): void {
    if (page < 1 || page > this.totalPages()) {
      return;
    }

    this.currentPage.set(page);
    this.openMenuId.set(null);
  }

  toggleMenu(id: number): void {
    this.openMenuId.update(current =>
      current === id ? null : id
    );
  }
}

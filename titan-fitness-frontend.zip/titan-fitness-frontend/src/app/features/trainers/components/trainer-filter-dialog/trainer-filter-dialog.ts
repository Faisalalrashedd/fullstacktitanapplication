import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-trainer-filter-dialog',
  styleUrl: './trainer-filter-dialog.css',
  templateUrl: './trainer-filter-dialog.html',
})
export class TrainerFilterDialog {}

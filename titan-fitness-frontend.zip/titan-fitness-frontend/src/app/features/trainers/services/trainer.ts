
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface TrainerDto {
  trainerId: number;
  trainerName: string;
  email: string | null;
  phone: string | null;
  isActive: boolean;
}

export interface SaveTrainerDto {
  trainerName: string;
  email: string | null;
  phone: string | null;
  isActive: boolean;
}

export interface TrainerSaveResult {
  trainerId?: number;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class TrainerService {
  private http = inject(HttpClient);
  private apiUrl = `${API_BASE_URL}/Trainers`;

  getTrainers(): Observable<TrainerDto[]> {
    return this.http.get<TrainerDto[]>(this.apiUrl);
  }

  getTrainer(id: number): Observable<TrainerDto> {
    return this.http.get<TrainerDto>(`${this.apiUrl}/${id}`);
  }

  addTrainer(trainer: SaveTrainerDto): Observable<TrainerSaveResult> {
    return this.http.post<TrainerSaveResult>(this.apiUrl, trainer);
  }

  updateTrainer(
    id: number,
    trainer: SaveTrainerDto
  ): Observable<TrainerSaveResult> {
    return this.http.put<TrainerSaveResult>(
      `${this.apiUrl}/${id}`,
      trainer
    );
  }
}

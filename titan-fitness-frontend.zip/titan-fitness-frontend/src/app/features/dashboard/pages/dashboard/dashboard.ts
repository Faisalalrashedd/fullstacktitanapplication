
import {
  Component,
  OnInit,
  computed,
  inject,
  signal
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { forkJoin } from 'rxjs';

import {
  DashboardService,
  DashboardStats,
  DashboardSession,
  DashboardTrainer,
  DashboardBranch
} from '../../services/dashboard';

import { CheckInDialog } from '../../../members/components/check-in-dialog/check-in-dialog';
import { MemberFormDialog } from '../../../members/components/member-form-dialog/member-form-dialog';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
  private dashboardService = inject(DashboardService);
  private dialog = inject(MatDialog);

  stats = signal<DashboardStats | null>(null);
  sessions = signal<DashboardSession[]>([]);
  trainers = signal<DashboardTrainer[]>([]);
  branches = signal<DashboardBranch[]>([]);

  searchTerm = signal('');
  selectedBranch = signal(0);

  loading = signal(true);
  errorMessage = signal('');

  today = this.localDate(new Date());

  private localDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard(): void {
    this.loading.set(true);
    this.errorMessage.set('');

    forkJoin({
      stats: this.dashboardService.getStats(),
      sessions: this.dashboardService.getSessions(this.today),
      trainers: this.dashboardService.getTrainers(),
      branches: this.dashboardService.getBranches()
    }).subscribe({
      next: ({ stats, sessions, trainers, branches }) => {
        this.stats.set(stats);
        this.sessions.set(sessions);
        this.trainers.set(trainers);
        this.branches.set(branches);
        this.loading.set(false);
      },
      error: error => {
        console.error('Dashboard load failed:', error);
        this.errorMessage.set('Unable to load dashboard data.');
        this.loading.set(false);
      }
    });
  }

  filteredClasses = computed(() => {
    const search = this.searchTerm().trim().toLowerCase();
    const branchId = this.selectedBranch();

    return this.sessions()
      .filter(session => session.status !== 3)
      .filter(session => {
        return branchId === 0 || session.branchId === branchId;
      })
      .filter(session => {
        if (!search) return true;

        return (
          session.className.toLowerCase().includes(search) ||
          this.trainerName(session.trainerId)
            .toLowerCase().includes(search) ||
          this.branchName(session.branchId)
            .toLowerCase().includes(search)
        );
      })
      .sort((a, b) =>
        a.startTime.localeCompare(b.startTime)
      );
  });

  updateSearch(event: Event): void {
    this.searchTerm.set(
      (event.target as HTMLInputElement).value
    );
  }

  updateBranch(event: Event): void {
    this.selectedBranch.set(
      Number((event.target as HTMLSelectElement).value)
    );
  }

  trainerName(id: number): string {
    return this.trainers().find(
      trainer => trainer.trainerId === id
    )?.trainerName || `Trainer #${id}`;
  }

  branchName(id: number): string {
    return this.branches().find(
      branch => branch.branchId === id
    )?.branchName || `Branch #${id}`;
  }

  formatTime(time: string): string {
    const parts = time.split(':');
    const hours = Number(parts[0]);
    const minutes = Number(parts[1]);

    if (Number.isNaN(hours) || Number.isNaN(minutes)) {
      return time;
    }

    const period = hours >= 12 ? 'PM' : 'AM';
    const hour = hours % 12 || 12;

    return `${String(hour).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${period}`;
  }

  statusText(status: number): string {
    switch (status) {
      case 0: return 'Open';
      case 1: return 'In Progress';
      case 2: return 'Completed';
      case 3: return 'Cancelled';
      default: return 'Unknown';
    }
  }

  openManualCheckIn(): void {
    const ref = this.dialog.open(CheckInDialog, {
      width: '580px',
      maxWidth: '95vw',
      autoFocus: false
    });

    ref.afterClosed().subscribe(result => {
      if (result?.completed) {
        this.loadDashboard();
      }
    });
  }

  openNewMember(): void {
    const ref = this.dialog.open(MemberFormDialog, {
      width: '700px',
      maxWidth: '95vw',
      autoFocus: false,
      data: { mode: 'add' }
    });

    ref.afterClosed().subscribe(result => {
      if (result?.saved) {
        this.loadDashboard();
      }
    });
  }
}

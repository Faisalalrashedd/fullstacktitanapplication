
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface DashboardStats {
  totalMembers: number;
  activeMemberships: number;
  todayCheckIns: number;
  upcomingSessions: number;
  activeTrainers: number;
}

export interface DashboardSession {
  sessionId: number;
  className: string;
  branchId: number;
  studioId: number;
  trainerId: number;
  sessionDate: string;
  startTime: string;
  durationInMinutes: number;
  capacityLimit: number;
  status: number;
  description: string | null;
}

export interface DashboardTrainer {
  trainerId: number;
  trainerName: string;
}

export interface DashboardBranch {
  branchId: number;
  branchName: string;
}

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private http = inject(HttpClient);

  getStats(): Observable<DashboardStats> {
    return this.http.get<DashboardStats>(
      `${API_BASE_URL}/Dashboard`
    );
  }

  getSessions(date: string): Observable<DashboardSession[]> {
    const params = new HttpParams().set('date', date);

    return this.http.get<DashboardSession[]>(
      `${API_BASE_URL}/Sessions`,
      { params }
    );
  }

  getTrainers(): Observable<DashboardTrainer[]> {
    return this.http.get<DashboardTrainer[]>(
      `${API_BASE_URL}/Trainers`
    );
  }

  getBranches(): Observable<DashboardBranch[]> {
    return this.http.get<DashboardBranch[]>(
      `${API_BASE_URL}/Branches`
    );
  }
}

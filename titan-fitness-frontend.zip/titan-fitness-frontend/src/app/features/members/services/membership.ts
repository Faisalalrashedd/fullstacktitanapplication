
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface MembershipDto {
  membershipId: number;
  memberId: number;
  planId: number;
  purchaseDate: string;
  startDate: string;
  endDate: string;
  status: number;
  pricePaid: number;
  durationInMonths: number;
  maximumFreezeDays: number;
  maximumNumberOfFreezes: number;
  guestPassQuota: number;
  accessScope: number;
}

export interface MembershipPlan {
  planId: number;
  planName: string;
  price: number;
  durationInMonths: number;
  maximumFreezeDays: number;
  maximumNumberOfFreezes: number;
  guestPassQuota: number;
  accessScope: number;
  isPublished: boolean;
}

export interface CreateMembershipRequest {
  planId: number;
  startDate: string;
}

export interface CreateMembershipResult {
  membershipId: number;
  message: string;
}

export interface FreezeRequest {
  startDate: string;
  endDate: string;
  reason: number;
  additionalNotes: string | null;
}

export interface FreezeResult {
  freezeId: number;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class MembershipService {
  private http = inject(HttpClient);

  getMemberMemberships(
    memberId: number
  ): Observable<MembershipDto[]> {
    return this.http.get<MembershipDto[]>(
      `${API_BASE_URL}/members/${memberId}/memberships`
    );
  }

  getPlans(): Observable<MembershipPlan[]> {
    return this.http.get<MembershipPlan[]>(
      `${API_BASE_URL}/Plans`
    );
  }

  createMembership(
    memberId: number,
    request: CreateMembershipRequest
  ): Observable<CreateMembershipResult> {
    return this.http.post<CreateMembershipResult>(
      `${API_BASE_URL}/members/${memberId}/memberships`,
      request
    );
  }

  createFreeze(
    membershipId: number,
    request: FreezeRequest
  ): Observable<FreezeResult> {
    return this.http.post<FreezeResult>(
      `${API_BASE_URL}/memberships/${membershipId}/freezes`,
      request
    );
  }
}


import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface CreateCheckInRequest {
  memberId: number;
  branchId: number;
}

export interface CheckInResult {
  checkInId: number;
  result: number;
  refusalReason: string | null;
}

export interface BranchDto {
  branchId: number;
  branchName: string;
}

@Injectable({
  providedIn: 'root'
})
export class CheckInService {
  private http = inject(HttpClient);

  createCheckIn(data: CreateCheckInRequest): Observable<CheckInResult> {
    return this.http.post<CheckInResult>(
      `${API_BASE_URL}/CheckIns`,
      data
    );
  }

  getBranches(): Observable<BranchDto[]> {
    return this.http.get<BranchDto[]>(
      `${API_BASE_URL}/Branches`
    );
  }
}

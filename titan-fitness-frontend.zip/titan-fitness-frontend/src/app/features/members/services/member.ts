
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface MemberDto {
  memberId: number;
  membershipNumber: string;
  fullName: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  joinedDate: string;
  photo: string | null;
  homeBranchId: number;
}

export type SaveMemberDto = Omit<MemberDto, 'memberId'>;

export interface MemberSaveResult {
  memberId?: number;
  message: string;
}

export interface PagedMembersResult {
  items: MemberDto[];
  totalCount: number;
  page: number;
  pageSize: number;
}

export interface MemberPageOptions {
  page: number;
  pageSize: number;
  search: string;
  branchId: number;
  sort: string;
  direction: string;
}

export interface MemberDirectoryDetail {
  memberId: number;
  status: string;
  lastVisit: string | null;
}

@Injectable({
  providedIn: 'root'
})
export class MemberService {
  private http = inject(HttpClient);
  private apiUrl = `${API_BASE_URL}/Members`;

  getMembers(): Observable<MemberDto[]> {
    return this.http.get<MemberDto[]>(this.apiUrl);
  }

  getPagedMembers(options: MemberPageOptions): Observable<PagedMembersResult> {
    const params = new HttpParams()
      .set('page', options.page)
      .set('pageSize', options.pageSize)
      .set('search', options.search)
      .set('branchId', options.branchId)
      .set('sort', options.sort)
      .set('direction', options.direction);

    return this.http.get<PagedMembersResult>(
      `${this.apiUrl}/paged`,
      { params }
    );
  }

  getDirectoryDetails(ids: number[]): Observable<MemberDirectoryDetail[]> {
    let params = new HttpParams();

    for (const id of ids) {
      params = params.append('ids', id);
    }

    return this.http.get<MemberDirectoryDetail[]>(
      `${this.apiUrl}/directory-details`,
      { params }
    );
  }

  getMember(id: number): Observable<MemberDto> {
    return this.http.get<MemberDto>(`${this.apiUrl}/${id}`);
  }

  addMember(member: SaveMemberDto): Observable<MemberSaveResult> {
    return this.http.post<MemberSaveResult>(this.apiUrl, member);
  }

  updateMember(
    id: number,
    member: SaveMemberDto
  ): Observable<MemberSaveResult> {
    return this.http.put<MemberSaveResult>(
      `${this.apiUrl}/${id}`,
      member
    );
  }
}

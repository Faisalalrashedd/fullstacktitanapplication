
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { finalize } from 'rxjs';

import {
  MembershipService,
  MembershipPlan
} from '../../services/membership';

export interface ActivateMembershipDialogData {
  memberId: number;
  memberName: string;
}

@Component({
  selector: 'app-activate-membership-dialog',
  standalone: true,
  imports: [ReactiveFormsModule, MatDialogModule],
  templateUrl: './activate-membership-dialog.html',
  styleUrl: './activate-membership-dialog.css'
})
export class ActivateMembershipDialog implements OnInit {
  private fb = inject(FormBuilder);
  private service = inject(MembershipService);
  private dialogRef = inject(MatDialogRef<ActivateMembershipDialog>);

  data = inject<ActivateMembershipDialogData>(MAT_DIALOG_DATA);

  plans = signal<MembershipPlan[]>([]);
  selectedPlanId = signal(0);
  loading = signal(true);
  saving = signal(false);
  errorMessage = signal('');

  today = this.getToday();

  form = this.fb.group({
    planId: [0, [Validators.required, Validators.min(1)]],
    startDate: [this.today, Validators.required]
  });

  availablePlans = computed(() =>
    this.plans().filter(plan => plan.isPublished)
  );

  selectedPlan = computed(() =>
    this.plans().find(
      plan => plan.planId === this.selectedPlanId()
    ) || null
  );

  private getToday(): string {
    const date = new Date();

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  ngOnInit(): void {
    this.service.getPlans().subscribe({
      next: plans => {
        this.plans.set(plans);
        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load plans:', error);
        this.errorMessage.set('Unable to load membership plans.');
        this.loading.set(false);
      }
    });
  }

  selectPlan(event: Event): void {
    const planId = Number(
      (event.target as HTMLSelectElement).value
    );

    this.selectedPlanId.set(planId);
    this.form.controls.planId.setValue(planId);
  }

  save(): void {
    if (this.form.invalid || this.saving() || this.loading()) {
      this.form.markAllAsTouched();
      return;
    }

    const value = this.form.getRawValue();

    if (!this.availablePlans().some(
      plan => plan.planId === Number(value.planId)
    )) {
      this.errorMessage.set('Select an available plan.');
      return;
    }

    this.saving.set(true);
    this.errorMessage.set('');

    this.service.createMembership(this.data.memberId, {
      planId: Number(value.planId),
      startDate: value.startDate || this.today
    }).pipe(
      finalize(() => this.saving.set(false))
    ).subscribe({
      next: result => {
        this.dialogRef.close({
          created: true,
          membershipId: result.membershipId
        });
      },
      error: error => {
        console.error('Membership creation failed:', error);

        const details = error.error;

        if (Array.isArray(details)) {
          this.errorMessage.set(
            details.map(item =>
              item.errorMessage || item.message || 'Invalid membership'
            ).join('; ')
          );
        } else {
          this.errorMessage.set(
            details?.message || 'Unable to activate membership.'
          );
        }
      }
    });
  }

  close(): void {
    this.dialogRef.close();
  }
}

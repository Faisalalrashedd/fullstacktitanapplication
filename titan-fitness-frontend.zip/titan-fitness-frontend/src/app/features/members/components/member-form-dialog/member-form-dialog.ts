
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef
} from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { finalize } from 'rxjs';

import {
  MemberDto,
  MemberService,
  SaveMemberDto
} from '../../services/member';
import { API_BASE_URL } from '../../../../core/api.config';
import { Autofocus } from '../../../../shared/directives/autofocus';

interface BranchDto {
  branchId: number;
  branchName: string;
}

export interface MemberDialogData {
  mode: 'add' | 'edit';
  member?: MemberDto;
}

@Component({
  selector: 'app-member-form-dialog',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    Autofocus
  ],
  templateUrl: './member-form-dialog.html',
  styleUrl: './member-form-dialog.css'
})
export class MemberFormDialog implements OnInit {
  private fb = inject(FormBuilder);
  private http = inject(HttpClient);
  private memberService = inject(MemberService);
  private dialogRef = inject(MatDialogRef<MemberFormDialog>);

  data = inject<MemberDialogData>(MAT_DIALOG_DATA);

  branches = signal<BranchDto[]>([]);
  loadingBranches = signal(true);
  saving = signal(false);
  errorMessage = signal('');

  isEditMode = this.data.mode === 'edit';

  private today(): string {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  form = this.fb.group({
    membershipNumber: ['', [
      Validators.required,
      Validators.maxLength(10)
    ]],
    fullName: ['', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(80),
      Validators.pattern(/^[A-Za-z\s'-]+$/)
    ]],
    homeBranchId: [null as number | null, Validators.required],
    email: ['', [
      Validators.email,
      Validators.maxLength(100)
    ]],
    phone: ['', Validators.maxLength(20)],
    address: ['', Validators.maxLength(200)],
    joinedDate: [this.today(), Validators.required]
  });

  ngOnInit(): void {
    if (this.isEditMode && this.data.member) {
      const member = this.data.member;

      this.form.patchValue({
        membershipNumber: member.membershipNumber,
        fullName: member.fullName,
        homeBranchId: member.homeBranchId,
        email: member.email || '',
        phone: member.phone || '',
        address: member.address || '',
        joinedDate: member.joinedDate?.slice(0, 10)
      });
    }

    this.http.get<BranchDto[]>(
      `${API_BASE_URL}/Branches`
    ).subscribe({
      next: branches => {
        this.branches.set(branches);
        this.loadingBranches.set(false);
      },
      error: error => {
        console.error('Failed to load branches:', error);
        this.errorMessage.set('Failed to load branches.');
        this.loadingBranches.set(false);
      }
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  save(): void {
    if (this.form.invalid || this.saving()) {
      this.form.markAllAsTouched();
      return;
    }

    const v = this.form.getRawValue();

    const request: SaveMemberDto = {
      membershipNumber: v.membershipNumber?.trim() || '',
      fullName: v.fullName?.trim() || '',
      homeBranchId: Number(v.homeBranchId),
      email: v.email?.trim() || null,
      phone: v.phone?.trim() || null,
      address: v.address?.trim() || null,
      joinedDate: v.joinedDate || this.today(),
      photo: this.data.member?.photo || null
    };

    this.saving.set(true);
    this.errorMessage.set('');

    const operation =
      this.isEditMode && this.data.member
        ? this.memberService.updateMember(
            this.data.member.memberId,
            request
          )
        : this.memberService.addMember(request);

    operation.pipe(
      finalize(() => this.saving.set(false))
    ).subscribe({
      next: result => {
        this.dialogRef.close({
          saved: true,
          memberId: result.memberId ??
            this.data.member?.memberId
        });
      },
      error: error => {
        console.error('Failed to save member:', error);

        if (Array.isArray(error.error)) {
          this.errorMessage.set(
            error.error.map((e: any) =>
              e.errorMessage || e.message || 'Validation error'
            ).join('; ')
          );
        } else {
          this.errorMessage.set(
            error.error?.message || 'Failed to save member.'
          );
        }
      }
    });
  }
}

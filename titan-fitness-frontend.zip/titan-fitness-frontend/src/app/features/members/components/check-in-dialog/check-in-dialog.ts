
import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { forkJoin, finalize } from 'rxjs';

import { MemberDto, MemberService } from '../../services/member';
import { CheckInService, BranchDto, CheckInResult } from '../../services/check-in';

export interface CheckInDialogData {
  memberId?: number;
}

@Component({
  selector: 'app-check-in-dialog',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, MatDialogModule],
  templateUrl: './check-in-dialog.html',
  styleUrl: './check-in-dialog.css'
})
export class CheckInDialog implements OnInit {
  private fb = inject(FormBuilder);
  private memberService = inject(MemberService);
  private checkInService = inject(CheckInService);
  private dialogRef = inject(MatDialogRef<CheckInDialog>);
  data = inject<CheckInDialogData>(MAT_DIALOG_DATA, { optional: true });

  members = signal<MemberDto[]>([]);
  branches = signal<BranchDto[]>([]);
  searchTerm = signal('');

  loading = signal(true);
  saving = signal(false);
  errorMessage = signal('');
  result = signal<CheckInResult | null>(null);

  form = this.fb.group({
    memberId: [null as number | null, Validators.required],
    branchId: [null as number | null, Validators.required]
  });

  filteredMembers = computed(() => {
    const search = this.searchTerm().trim().toLowerCase();

    if (!search) return this.members();

    return this.members().filter(member =>
      member.fullName.toLowerCase().includes(search) ||
      member.membershipNumber.toLowerCase().includes(search)
    );
  });

  selectedMember = computed(() =>
    this.members().find(
      member => member.memberId === Number(this.form.value.memberId)
    )
  );

  ngOnInit(): void {
    forkJoin({
      members: this.memberService.getMembers(),
      branches: this.checkInService.getBranches()
    }).subscribe({
      next: ({ members, branches }) => {
        this.members.set(members);
        this.branches.set(branches);

        if (this.data?.memberId) {
          const member = members.find(m => m.memberId === this.data?.memberId);

          if (member) {
            this.form.patchValue({
              memberId: member.memberId,
              branchId: member.homeBranchId
            });

            this.searchTerm.set(member.fullName);
          }
        }

        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load check-in data:', error);
        this.errorMessage.set('Unable to load members or branches.');
        this.loading.set(false);
      }
    });
  }

  updateSearch(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  selectMember(member: MemberDto): void {
    this.form.patchValue({
      memberId: member.memberId,
      branchId: member.homeBranchId
    });

    this.searchTerm.set(member.fullName);
  }

  cancel(): void {
    this.dialogRef.close();
  }

  submit(): void {
    if (this.form.invalid || this.saving() || this.result()) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving.set(true);
    this.errorMessage.set('');

    this.checkInService.createCheckIn({
      memberId: Number(this.form.value.memberId),
      branchId: Number(this.form.value.branchId)
    }).pipe(
      finalize(() => this.saving.set(false))
    ).subscribe({
      next: response => {
        this.result.set(response);
      },
      error: error => {
        console.error('Check-in failed:', error);
        this.errorMessage.set(
          error.error?.message || 'Unable to complete check-in.'
        );
      }
    });
  }

  finish(): void {
    this.dialogRef.close({
      completed: true,
      result: this.result()
    });
  }
}

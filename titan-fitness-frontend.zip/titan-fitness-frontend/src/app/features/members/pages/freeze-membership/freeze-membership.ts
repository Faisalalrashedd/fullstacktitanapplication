
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { forkJoin, finalize } from 'rxjs';

import { MemberDto, MemberService } from '../../services/member';
import {
  MembershipDto,
  MembershipPlan,
  MembershipService
} from '../../services/membership';
import { StatusBadge } from '../../../../shared/components/status-badge/status-badge';

@Component({
  selector: 'app-freeze-membership',
  standalone: true,
  imports: [RouterLink, DatePipe, StatusBadge],
  templateUrl: './freeze-membership.html',
  styleUrl: './freeze-membership.css'
})
export class FreezeMembership implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private memberService = inject(MemberService);
  private membershipService = inject(MembershipService);

  memberId = signal(0);
  member = signal<MemberDto | null>(null);
  membership = signal<MembershipDto | null>(null);
  plans = signal<MembershipPlan[]>([]);

  loading = signal(true);
  saving = signal(false);
  errorMessage = signal('');
  successMessage = signal('');
  freezeCompleted = signal(false);

  startDate = signal('');
  duration = signal(1);
  reason = signal('');
  notes = signal('');

  private pad(value: number): string {
    return String(value).padStart(2, '0');
  }

  private parseDate(value: string): Date {
    const [year, month, day] = value.slice(0, 10).split('-').map(Number);
    return new Date(year, month - 1, day);
  }

  private formatDate(date: Date): string {
    return (
      `${date.getFullYear()}-${this.pad(date.getMonth() + 1)}-` +
      this.pad(date.getDate())
    );
  }

  private addMonths(date: Date, months: number): Date {
    const result = new Date(date);
    const day = result.getDate();

    result.setDate(1);
    result.setMonth(result.getMonth() + months);

    const lastDay = new Date(
      result.getFullYear(),
      result.getMonth() + 1,
      0
    ).getDate();

    result.setDate(Math.min(day, lastDay));
    return result;
  }

  today = this.formatDate(new Date());

  statusName = computed(() => {
    const status = this.membership()?.status;

    switch (status) {
      case 0: return 'Pending';
      case 1: return 'Active';
      case 2: return 'Frozen';
      case 3: return 'Expired';
      case 4: return 'Cancelled';
      default: return 'Unknown';
    }
  });

  planName = computed(() => {
    const membership = this.membership();
    if (!membership) return 'No membership';

    return this.plans().find(
      plan => plan.planId === membership.planId
    )?.planName || `Plan #${membership.planId}`;
  });

  initials = computed(() => {
    const name = this.member()?.fullName || '';

    return name.trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map(part => part[0].toUpperCase())
      .join('');
  });

  canFreezeMembership = computed(() => {
    const membership = this.membership();

    return !!membership &&
      membership.status === 1 &&
      membership.maximumFreezeDays > 0 &&
      membership.maximumNumberOfFreezes > 0;
  });

  freezeEndDate = computed(() => {
    if (!this.startDate()) return '';

    const date = this.parseDate(this.startDate());
    const end = this.addMonths(date, this.duration());

    // freeze end is inclusive
    end.setDate(end.getDate() - 1);

    return this.formatDate(end);
  });

  freezeDays = computed(() => {
    if (!this.startDate() || !this.freezeEndDate()) return 0;

    const start = this.parseDate(this.startDate());
    const end = this.parseDate(this.freezeEndDate());

    return Math.round(
      (Date.UTC(end.getFullYear(), end.getMonth(), end.getDate()) -
       Date.UTC(start.getFullYear(), start.getMonth(), start.getDate())) /
      86400000
    ) + 1;
  });

  originalEndDate = computed(() =>
    this.membership()?.endDate || ''
  );

  newEndDate = computed(() => {
    if (!this.originalEndDate() || !this.startDate()) return '';

    const result = this.parseDate(this.originalEndDate());
    result.setDate(result.getDate() + this.freezeDays());

    return this.formatDate(result);
  });

  dateValid = computed(() => {
    const membership = this.membership();

    if (!membership || !this.startDate() || !this.freezeEndDate()) {
      return false;
    }

    return this.startDate() >= this.today &&
      this.startDate() >= membership.startDate.slice(0, 10) &&
      this.freezeEndDate() <= membership.endDate.slice(0, 10);
  });

  durationWithinLimit = computed(() => {
    const membership = this.membership();

    return !!membership &&
      this.freezeDays() > 0 &&
      this.freezeDays() <= membership.maximumFreezeDays;
  });

  validForm = computed(() =>
    this.canFreezeMembership() &&
    this.dateValid() &&
    this.durationWithinLimit() &&
    !!this.reason() &&
    this.notes().length <= 200 &&
    !this.saving() &&
    !this.freezeCompleted()
  );

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    if (!Number.isInteger(id) || id <= 0) {
      this.errorMessage.set('Invalid member ID.');
      this.loading.set(false);
      return;
    }

    this.memberId.set(id);
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.errorMessage.set('');

    forkJoin({
      member: this.memberService.getMember(this.memberId()),
      memberships: this.membershipService.getMemberMemberships(this.memberId()),
      plans: this.membershipService.getPlans()
    }).subscribe({
      next: ({ member, memberships, plans }) => {
        this.member.set(member);
        this.plans.set(plans);

        // prefer the latest active membership
        const sorted = [...memberships].sort(
          (a, b) => b.startDate.localeCompare(a.startDate)
        );

        const active = sorted.find(item =>
          item.status === 1 &&
          item.startDate.slice(0, 10) <= this.today &&
          item.endDate.slice(0, 10) >= this.today
        );

        this.membership.set(active || sorted[0] || null);
        this.loading.set(false);
      },
      error: error => {
        console.error('Unable to load membership:', error);
        this.errorMessage.set('Unable to load membership information.');
        this.loading.set(false);
      }
    });
  }

  setStartDate(event: Event): void {
    this.startDate.set((event.target as HTMLInputElement).value);
  }

  setDuration(months: number): void {
    this.duration.set(months);
  }

  setReason(event: Event): void {
    this.reason.set((event.target as HTMLSelectElement).value);
  }

  setNotes(event: Event): void {
    this.notes.set((event.target as HTMLTextAreaElement).value);
  }

  confirmFreeze(): void {
    const membership = this.membership();

    if (!membership || !this.validForm()) return;

    this.saving.set(true);
    this.errorMessage.set('');
    this.successMessage.set('');

    this.membershipService.createFreeze(
      membership.membershipId,
      {
        startDate: this.startDate(),
        endDate: this.freezeEndDate(),
        reason: Number(this.reason()),
        additionalNotes: this.notes().trim() || null
      }
    ).pipe(
      finalize(() => this.saving.set(false))
    ).subscribe({
      next: result => {
        this.freezeCompleted.set(true);
        this.successMessage.set(
          result.message || 'Membership frozen successfully.'
        );

        // reload after the backend updates membership dates
        this.membershipService.getMemberMemberships(
          this.memberId()
        ).subscribe({
          next: memberships => {
            const updated = memberships.find(
              item => item.membershipId === membership.membershipId
            );

            if (updated) this.membership.set(updated);
          },
          error: () => {}
        });
      },
      error: error => {
        console.error('Freeze failed:', error);

        const details = error.error;

        if (Array.isArray(details)) {
          this.errorMessage.set(
            details.map(item =>
              item.errorMessage || item.message || 'Invalid freeze'
            ).join('; ')
          );
        } else {
          this.errorMessage.set(
            details?.message || 'Unable to freeze membership.'
          );
        }
      }
    });
  }

  backToProfile(): void {
    this.router.navigate(['/members', this.memberId()]);
  }
}

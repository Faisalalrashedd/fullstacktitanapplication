
import {
  Component,
  OnInit,
  computed,
  inject,
  signal
} from '@angular/core';

import { DatePipe } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { forkJoin } from 'rxjs';
import { ActivateMembershipDialog } from '../../components/activate-membership-dialog/activate-membership-dialog';

import {
  MemberService,
  MemberDto
} from '../../services/member';

import {
  MembershipService,
  MembershipDto,
  MembershipPlan
} from '../../services/membership';

import {
  MemberFormDialog
} from '../../components/member-form-dialog/member-form-dialog';

import {
  StatusBadge
} from '../../../../shared/components/status-badge/status-badge';

@Component({
  selector: 'app-member-profile',
  standalone: true,
  imports: [
    RouterLink,
    DatePipe,
    StatusBadge
  ],
  templateUrl: './member-profile.html',
  styleUrl: './member-profile.css'
})
export class MemberProfile implements OnInit {
  private route = inject(ActivatedRoute);
  private memberService = inject(MemberService);
  private membershipService = inject(MembershipService);
  private dialog = inject(MatDialog);

  memberId = signal(0);
  member = signal<MemberDto | null>(null);
  membership = signal<MembershipDto | null>(null);
  plans = signal<MembershipPlan[]>([]);

  loading = signal(true);
  errorMessage = signal('');
  membershipError = signal('');

  private today(): string {
    const date = new Date();

    return [
      date.getFullYear(),
      String(date.getMonth() + 1).padStart(2, '0'),
      String(date.getDate()).padStart(2, '0')
    ].join('-');
  }

  planName = computed(() => {
    const membership = this.membership();

    if (!membership) {
      return 'No Membership';
    }

    const plan = this.plans().find(
      item => item.planId === membership.planId
    );

    return plan?.planName || `Plan #${membership.planId}`;
  });

  membershipStatus = computed(() => {
    const status = this.membership()?.status;

    switch (status) {
      case 0: return 'Pending';
      case 1: return 'Active';
      case 2: return 'Frozen';
      case 3: return 'Expired';
      case 4: return 'Cancelled';
      default: return 'Unknown';
    }
  });

  hasActiveMembership = computed(() => {
    const membership = this.membership();

    if (!membership) return false;

    const today = this.today();

    return membership.status === 1 &&
      membership.startDate.slice(0, 10) <= today &&
      membership.endDate.slice(0, 10) >= today;
  });

  hasFreezeAllowance = computed(() => {
    const membership = this.membership();

    return this.hasActiveMembership() &&
      !!membership &&
      membership.maximumFreezeDays > 0 &&
      membership.maximumNumberOfFreezes > 0;
  });

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    if (!Number.isInteger(id) || id <= 0) {
      this.errorMessage.set('Invalid member ID.');
      this.loading.set(false);
      return;
    }

    this.memberId.set(id);
    this.loadMember();
  }

  loadMember(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.membershipError.set('');

    this.memberService.getMember(this.memberId()).subscribe({
      next: member => {
        this.member.set(member);
        this.loading.set(false);
        this.loadMembership();
      },
      error: error => {
        console.error('Failed to load member:', error);

        this.errorMessage.set(
          error.status === 404
            ? 'Member not found.'
            : 'Failed to load member.'
        );

        this.loading.set(false);
      }
    });
  }

  loadMembership(): void {
    forkJoin({
      memberships: this.membershipService.getMemberMemberships(
        this.memberId()
      ),
      plans: this.membershipService.getPlans()
    }).subscribe({
      next: ({ memberships, plans }) => {
        this.plans.set(plans);

        const sorted = [...memberships].sort(
          (a, b) => b.startDate.localeCompare(a.startDate)
        );

        const today = this.today();

        const active = sorted.find(item =>
          item.status === 1 &&
          item.startDate.slice(0, 10) <= today &&
          item.endDate.slice(0, 10) >= today
        );

        const frozen = sorted.find(item =>
          item.status === 2
        );

        this.membership.set(
          active || frozen || sorted[0] || null
        );
      },
      error: error => {
        console.error('Failed to load memberships:', error);
        this.membershipError.set(
          'Unable to load membership details.'
        );
      }
    });
  }

  openEditMember(): void {
    const currentMember = this.member();

    if (!currentMember) return;

    const ref = this.dialog.open(MemberFormDialog, {
      width: '700px',
      maxWidth: '95vw',
      autoFocus: false,
      data: {
        mode: 'edit',
        member: currentMember
      }
    });

    ref.afterClosed().subscribe(result => {
      if (result?.saved) {
        this.loadMember();
      }
    });
  }

  getInitials(name: string): string {
    return name.trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map(part => part[0].toUpperCase())
      .join('');
  }
  
openActivateMembership(): void {
  const currentMember = this.member();

  if (!currentMember) return;

  const ref = this.dialog.open(ActivateMembershipDialog, {
    width: '600px',
    maxWidth: '95vw',
    maxHeight: '90vh',
    autoFocus: false,
    data: {
      memberId: currentMember.memberId,
      memberName: currentMember.fullName
    }
  });

  ref.afterClosed().subscribe(result => {
    if (result?.created) {
      this.loadMembership();
    }
  });
}

}


import {
  Component,
  OnInit,
  OnDestroy,
  computed,
  inject,
  signal
} from '@angular/core';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { Subscription, of, switchMap, map } from 'rxjs';

import { StatusBadge } from '../../../../shared/components/status-badge/status-badge';
import { Paginator } from '../../../../shared/components/paginator/paginator';
import { HighlightPipe } from '../../../../shared/pipes/highlight-pipe';
import { ClickOutside } from '../../../../shared/directives/click-outside';

import {
  MemberService,
  MemberDirectoryDetail
} from '../../services/member';

import { MemberFormDialog } from '../../components/member-form-dialog/member-form-dialog';
import { CheckInDialog } from '../../components/check-in-dialog/check-in-dialog';
import { CheckInService, BranchDto } from '../../services/check-in';

interface MemberRow {
  id: number;
  memberId: string;
  name: string;
  initials: string;
  status: string;
  branchId: number;
  branch: string;
  lastVisit: string;
}

type SortField = 'name' | 'memberId' | 'branch';

@Component({
  selector: 'app-member-directory',
  standalone: true,
  imports: [
    RouterLink,
    StatusBadge,
    Paginator,
    HighlightPipe,
    ClickOutside
  ],
  templateUrl: './member-directory.html',
  styleUrl: './member-directory.css'
})
export class MemberDirectory implements OnInit, OnDestroy {
  private memberService = inject(MemberService);
  private checkInService = inject(CheckInService);
  private dialog = inject(MatDialog);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  private request?: Subscription;
  private searchTimer?: ReturnType<typeof setTimeout>;

  members = signal<MemberRow[]>([]);
  branches = signal<BranchDto[]>([]);

  searchTerm = signal('');
  selectedBranch = signal(0);
  sortField = signal<SortField>('name');
  sortDirection = signal<'asc' | 'desc'>('asc');
  currentPage = signal(1);

  totalCount = signal(0);
  pageSize = 4;

  showFilters = signal(false);
  openMenuId = signal<number | null>(null);
  loading = signal(false);
  errorMessage = signal('');

  totalPages = computed(() =>
    Math.max(1, Math.ceil(this.totalCount() / this.pageSize))
  );

  pagedMembers = computed(() => this.members());

  ngOnInit(): void {
    const params = this.route.snapshot.queryParamMap;

    this.searchTerm.set(params.get('search') || '');

    const branch = Number(params.get('branch') || '0');
    this.selectedBranch.set(
      Number.isInteger(branch) && branch >= 0 ? branch : 0
    );

    const sort = params.get('sort');

    if (sort === 'name' || sort === 'memberId' || sort === 'branch') {
      this.sortField.set(sort);
    }

    this.sortDirection.set(
      params.get('direction') === 'desc' ? 'desc' : 'asc'
    );

    const page = Number(params.get('page') || '1');
    this.currentPage.set(
      Number.isInteger(page) && page > 0 ? page : 1
    );

    this.loadBranches();
    this.loadMembers();
  }

  ngOnDestroy(): void {
    this.request?.unsubscribe();

    if (this.searchTimer) {
      clearTimeout(this.searchTimer);
    }
  }

  branchName(id: number): string {
    return this.branches().find(
      branch => branch.branchId === id
    )?.branchName || `Branch ${id}`;
  }

  loadBranches(): void {
    this.checkInService.getBranches().subscribe({
      next: branches => {
        this.branches.set(branches);

        this.members.update(rows =>
          rows.map(member => ({
            ...member,
            branch: this.branchName(member.branchId)
          }))
        );
      },
      error: error => {
        console.error('Failed to load branches:', error);
      }
    });
  }

  formatLastVisit(value: string | null): string {
    if (!value) return 'Never';

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return 'Unknown';

    const today = new Date();

    const sameDay =
      date.getFullYear() === today.getFullYear() &&
      date.getMonth() === today.getMonth() &&
      date.getDate() === today.getDate();

    const time = date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit'
    });

    if (sameDay) return `Today, ${time}`;

    const day = date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });

    return `${day}, ${time}`;
  }

  loadMembers(): void {
    this.request?.unsubscribe();

    this.loading.set(true);
    this.errorMessage.set('');

    this.request = this.memberService.getPagedMembers({
      page: this.currentPage(),
      pageSize: this.pageSize,
      search: this.searchTerm(),
      branchId: this.selectedBranch(),
      sort: this.sortField(),
      direction: this.sortDirection()
    }).pipe(
      switchMap(result => {
        if (result.items.length === 0) {
          return of({
            result,
            details: [] as MemberDirectoryDetail[]
          });
        }

        const ids = result.items.map(member => member.memberId);

        return this.memberService.getDirectoryDetails(ids).pipe(
          map(details => ({ result, details }))
        );
      })
    ).subscribe({
      next: ({ result, details }) => {
        this.totalCount.set(result.totalCount);

        const detailMap = new Map(
          details.map(detail => [detail.memberId, detail])
        );

        this.members.set(result.items.map(member => {
          const detail = detailMap.get(member.memberId);

          return {
            id: member.memberId,
            memberId: member.membershipNumber,
            name: member.fullName,
            initials: member.fullName.trim()
              .split(/\s+/)
              .filter(Boolean)
              .slice(0, 2)
              .map(part => part[0].toUpperCase())
              .join(''),
            status: detail?.status || 'Unknown',
            branchId: member.homeBranchId,
            branch: this.branchName(member.homeBranchId),
            lastVisit: this.formatLastVisit(
              detail?.lastVisit || null
            )
          };
        }));

        this.loading.set(false);

        if (this.currentPage() > this.totalPages()) {
          this.currentPage.set(this.totalPages());
          this.updateUrl();
          this.loadMembers();
        }
      },
      error: error => {
        console.error('Failed to load member directory:', error);
        this.errorMessage.set(
          'Unable to load member records or membership details.'
        );
        this.loading.set(false);
      }
    });
  }

  updateSearch(event: Event): void {
    this.searchTerm.set(
      (event.target as HTMLInputElement).value
    );

    this.currentPage.set(1);
    this.updateUrl();

    if (this.searchTimer) clearTimeout(this.searchTimer);

    this.searchTimer = setTimeout(() => {
      this.loadMembers();
    }, 300);
  }

  updateBranch(event: Event): void {
    this.selectedBranch.set(
      Number((event.target as HTMLSelectElement).value)
    );

    this.resetPage();
  }

  sortBy(field: SortField): void {
    if (this.sortField() === field) {
      this.sortDirection.update(direction =>
        direction === 'asc' ? 'desc' : 'asc'
      );
    } else {
      this.sortField.set(field);
      this.sortDirection.set('asc');
    }

    this.resetPage();
  }

  sortIcon(field: SortField): string {
    if (this.sortField() !== field) return '↕';
    return this.sortDirection() === 'asc' ? '↑' : '↓';
  }

  toggleFilters(): void {
    this.showFilters.update(value => !value);
  }

  clearFilters(): void {
    this.selectedBranch.set(0);
    this.searchTerm.set('');
    this.sortField.set('name');
    this.sortDirection.set('asc');
    this.showFilters.set(false);

    this.resetPage();
  }

  resetPage(): void {
    if (this.searchTimer) clearTimeout(this.searchTimer);

    this.currentPage.set(1);
    this.openMenuId.set(null);

    this.updateUrl();
    this.loadMembers();
  }

  changePage(page: number): void {
    if (page < 1 || page > this.totalPages()) return;

    this.currentPage.set(page);
    this.openMenuId.set(null);

    this.updateUrl();
    this.loadMembers();
  }

  updateUrl(): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        search: this.searchTerm() || null,
        branch: this.selectedBranch() || null,
        sort: this.sortField(),
        direction: this.sortDirection(),
        page: this.currentPage()
      },
      queryParamsHandling: 'merge',
      replaceUrl: true
    });
  }

  openAddMember(): void {
    const ref = this.dialog.open(MemberFormDialog, {
      width: '700px',
      maxWidth: '95vw',
      autoFocus: false,
      data: { mode: 'add' }
    });

    ref.afterClosed().subscribe(result => {
      if (result?.saved) this.loadMembers();
    });
  }

  openCheckIn(memberId: number): void {
    this.openMenuId.set(null);

    const ref = this.dialog.open(CheckInDialog, {
      width: '580px',
      maxWidth: '95vw',
      autoFocus: false,
      data: { memberId }
    });

    ref.afterClosed().subscribe(result => {
      if (result?.completed) this.loadMembers();
    });
  }

  toggleMenu(memberId: number): void {
    this.openMenuId.update(current =>
      current === memberId ? null : memberId
    );
  }

  closeMenu(): void {
    this.openMenuId.set(null);
  }
}


import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface BookingDto {
  bookingId: number;
  sessionId: number;
  memberId: number;
  bookedOn: string;
  status: number;
  waitlistPosition: number | null;
  notesForTrainer: string | null;
}

export interface CreateBookingRequest {
  memberId: number;
  notesForTrainer: string | null;
}

export interface CreateBookingResult {
  bookingId: number;
  status: number;
  waitlistPosition: number | null;
}

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private http = inject(HttpClient);

  getBookings(sessionId: number): Observable<BookingDto[]> {
    return this.http.get<BookingDto[]>(
      `${API_BASE_URL}/sessions/${sessionId}/bookings`
    );
  }

  createBooking(
    sessionId: number,
    data: CreateBookingRequest
  ): Observable<CreateBookingResult> {
    return this.http.post<CreateBookingResult>(
      `${API_BASE_URL}/sessions/${sessionId}/bookings`,
      data
    );
  }

  cancelBooking(bookingId: number): Observable<unknown> {
    return this.http.delete(
      `${API_BASE_URL}/bookings/${bookingId}`
    );
  }
}

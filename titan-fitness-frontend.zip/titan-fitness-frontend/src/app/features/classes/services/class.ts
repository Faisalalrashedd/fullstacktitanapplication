
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface ClassSessionDto {
  sessionId: number;
  className: string;
  branchId: number;
  studioId: number;
  trainerId: number;
  sessionDate: string;
  startTime: string;
  durationInMinutes: number;
  capacityLimit: number;
  status: number;
  description: string | null;
}

export interface CreateSessionDto {
  className: string;
  branchId: number;
  studioId: number;
  trainerId: number;
  sessionDate: string;
  startTime: string;
  durationInMinutes: number;
  capacityLimit: number;
  description: string | null;
}

export interface BranchDto {
  branchId: number;
  branchName: string;
}

export interface StudioDto {
  studioId: number;
  studioName: string;
  branchId: number;
  capacity: number;
}

export interface TrainerOptionDto {
  trainerId: number;
  trainerName: string;
  isActive: boolean;
}

export interface CreateSessionResult {
  sessionId: number;
  message: string;
}

export interface SessionActionResult {
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class ClassService {
  private http = inject(HttpClient);

  getSessions(
    branchId?: number,
    date?: string
  ): Observable<ClassSessionDto[]> {
    let params = new HttpParams();

    if (branchId !== undefined) {
      params = params.set('branchId', branchId);
    }

    if (date) {
      params = params.set('date', date);
    }

    return this.http.get<ClassSessionDto[]>(
      `${API_BASE_URL}/Sessions`,
      { params }
    );
  }

  getSession(id: number): Observable<ClassSessionDto> {
    return this.http.get<ClassSessionDto>(
      `${API_BASE_URL}/Sessions/${id}`
    );
  }

  createSession(
    data: CreateSessionDto
  ): Observable<CreateSessionResult> {
    return this.http.post<CreateSessionResult>(
      `${API_BASE_URL}/Sessions`,
      data
    );
  }

  updateSession(
    id: number,
    data: CreateSessionDto
  ): Observable<SessionActionResult> {
    return this.http.put<SessionActionResult>(
      `${API_BASE_URL}/Sessions/${id}`,
      data
    );
  }

  cancelSession(id: number): Observable<SessionActionResult> {
    return this.http.patch<SessionActionResult>(
      `${API_BASE_URL}/Sessions/${id}/cancel`,
      {}
    );
  }

  getBranches(): Observable<BranchDto[]> {
    return this.http.get<BranchDto[]>(
      `${API_BASE_URL}/Branches`
    );
  }

  getStudios(branchId: number): Observable<StudioDto[]> {
    return this.http.get<StudioDto[]>(
      `${API_BASE_URL}/Branches/${branchId}/studios`
    );
  }

  getTrainers(): Observable<TrainerOptionDto[]> {
    return this.http.get<TrainerOptionDto[]>(
      `${API_BASE_URL}/Trainers`
    );
  }
}

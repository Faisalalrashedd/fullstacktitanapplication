
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { forkJoin, of, catchError } from 'rxjs';

import { ClassFormDialog } from '../../components/class-form-dialog/class-form-dialog';
import { BookSessionDialog, BookingDialogData } from '../../components/book-session-dialog/book-session-dialog';
import { ClassDetailsDialog } from '../../components/class-details-dialog/class-details-dialog';

import {
  ClassService,
  ClassSessionDto,
  BranchDto,
  StudioDto,
  TrainerOptionDto,
  CreateSessionDto
} from '../../services/class';

import {
  BookingService,
  BookingDto,
  CreateBookingResult
} from '../../services/booking';

@Component({
  selector: 'app-class-schedule',
  standalone: true,
  imports: [MatDialogModule],
  templateUrl: './class-schedule.html',
  styleUrl: './class-schedule.css'
})
export class ClassSchedule implements OnInit {
  private classService = inject(ClassService);
  private bookingService = inject(BookingService);
  private dialog = inject(MatDialog);

  branches = signal<BranchDto[]>([]);
  trainers = signal<TrainerOptionDto[]>([]);
  studios = signal<StudioDto[]>([]);
  sessions = signal<ClassSessionDto[]>([]);

  bookings = signal<Record<number, BookingDto[]>>({});
  bookingErrors = signal<number[]>([]);

  selectedBranch = signal(0);
  selectedDate = signal(this.localDate(new Date()));
  searchTerm = signal('');

  loading = signal(false);
  errorMessage = signal('');
  bookingMessage = signal('');

  visibleSessions = computed(() => {
    const search = this.searchTerm().trim().toLowerCase();

    return this.sessions().filter(session => {
      const name = session.className.toLowerCase();
      const trainer = this.trainerName(session.trainerId).toLowerCase();
      const studio = this.studioName(session.studioId).toLowerCase();

      return !search ||
        name.includes(search) ||
        trainer.includes(search) ||
        studio.includes(search);
    });
  });

  totalBookings = computed(() =>
    this.visibleSessions().reduce(
      (total, session) => total + this.enrolled(session.sessionId),
      0
    )
  );

  averageFillRate = computed(() => {
    const sessions = this.visibleSessions();
    if (!sessions.length) return 0;

    const total = sessions.reduce(
      (sum, session) => sum + this.fillPercent(session),
      0
    );

    return Math.round(total / sessions.length);
  });

  ngOnInit(): void {
    forkJoin({
      branches: this.classService.getBranches(),
      trainers: this.classService.getTrainers()
    }).subscribe({
      next: result => {
        this.branches.set(result.branches);
        this.trainers.set(result.trainers);
        this.loadStudios();
        this.loadSessions();
      },
      error: error => {
        console.error('Failed to load options:', error);
        this.errorMessage.set('Failed to load branches or trainers.');
      }
    });
  }

  localDate(date: Date): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  loadStudios(): void {
    if (!this.branches().length) {
      this.studios.set([]);
      return;
    }

    forkJoin(
      this.branches().map(branch =>
        this.classService.getStudios(branch.branchId)
      )
    ).subscribe({
      next: results => this.studios.set(results.flat()),
      error: error => console.error('Failed to load studios:', error)
    });
  }

  loadSessions(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.bookings.set({});
    this.bookingErrors.set([]);

    this.classService.getSessions(
      this.selectedBranch() || undefined,
      this.selectedDate()
    ).subscribe({
      next: sessions => {
        this.sessions.set(sessions);
        this.loading.set(false);
        this.loadBookings(sessions);
      },
      error: error => {
        console.error('Failed to load sessions:', error);
        this.errorMessage.set('Failed to load classes.');
        this.loading.set(false);
      }
    });
  }

  loadBookings(sessions: ClassSessionDto[]): void {
    if (!sessions.length) return;

    this.bookingErrors.set([]);

    const requests = sessions.map(session =>
      this.bookingService.getBookings(session.sessionId).pipe(
        catchError(error => {
          console.error('Failed to load bookings:', session.sessionId, error);
          this.bookingErrors.update(ids => [...ids, session.sessionId]);
          return of(null);
        })
      )
    );

    forkJoin(requests).subscribe(results => {
      const mapped: Record<number, BookingDto[]> = {};

      sessions.forEach((session, index) => {
        const result = results[index];
        if (result !== null) {
          mapped[session.sessionId] = result;
        }
      });

      this.bookings.set(mapped);
    });
  }

  enrolled(sessionId: number): number {
    return (this.bookings()[sessionId] || [])
      .filter(b =>
        b.status === 0 ||
        b.status === 2 ||
        b.status === 3
      ).length;
  }

  waitlisted(sessionId: number): number {
    return (this.bookings()[sessionId] || [])
      .filter(b => b.status === 1).length;
  }

  hasBookingData(sessionId: number): boolean {
    return Object.prototype.hasOwnProperty.call(
      this.bookings(),
      sessionId
    );
  }

  fillPercent(session: ClassSessionDto): number {
    if (!session.capacityLimit) return 0;

    return Math.min(
      100,
      this.enrolled(session.sessionId) /
      session.capacityLimit * 100
    );
  }

  trainerName(id: number): string {
    return this.trainers().find(
      trainer => trainer.trainerId === id
    )?.trainerName ?? `Trainer ${id}`;
  }

  studioName(id: number): string {
    return this.studios().find(
      studio => studio.studioId === id
    )?.studioName ?? `Studio ${id}`;
  }

  branchName(id: number): string {
    return this.branches().find(
      branch => branch.branchId === id
    )?.branchName ?? `Branch ${id}`;
  }

  formatTime(value: string): string {
    const parts = value.split(':');
    const hour = Number(parts[0]);
    const minute = parts[1] ?? '00';

    return `${String(hour % 12 || 12).padStart(2, '0')}:${minute} ${hour >= 12 ? 'PM' : 'AM'}`;
  }

  statusText(session: ClassSessionDto): string {
    switch (session.status) {
      case 0: return 'Upcoming';
      case 1: return 'In Progress';
      case 2: return 'Completed';
      case 3: return 'Cancelled';
      default: return 'Unknown';
    }
  }

  canBook(session: ClassSessionDto): boolean {
    const start = new Date(
      `${session.sessionDate.slice(0, 10)}T${session.startTime}`
    );

    return session.status === 0 && start > new Date();
  }

  changeBranch(event: Event): void {
    this.selectedBranch.set(
      Number((event.target as HTMLSelectElement).value)
    );
    this.loadSessions();
  }

  changeDate(event: Event): void {
    this.selectedDate.set(
      (event.target as HTMLInputElement).value
    );
    this.loadSessions();
  }

  changeDay(days: number): void {
    const date = new Date(`${this.selectedDate()}T12:00:00`);
    date.setDate(date.getDate() + days);
    this.selectedDate.set(this.localDate(date));
    this.loadSessions();
  }

  updateSearch(event: Event): void {
    this.searchTerm.set(
      (event.target as HTMLInputElement).value
    );
  }

  openClassDetails(session: ClassSessionDto): void {
    const ref = this.dialog.open(ClassDetailsDialog, {
      width: '750px',
      maxWidth: '95vw',
      maxHeight: '90vh',
      autoFocus: false,
      data: {
        sessionId: session.sessionId
      }
    });

    ref.afterClosed().subscribe(result => {
      if (result?.updated || result?.cancelled) {
        this.bookingMessage.set(
          result.cancelled
            ? 'Class cancelled successfully.'
            : 'Class updated successfully.'
        );

        this.loadSessions();
      }
    });
  }

  openBooking(session: ClassSessionDto): void {
    const data: BookingDialogData = {
      sessionId: session.sessionId,
      className: session.className,
      trainer: this.trainerName(session.trainerId),
      studio: this.studioName(session.studioId),
      date: session.sessionDate,
      time: this.formatTime(session.startTime),
      capacity: session.capacityLimit,
      enrolled: this.enrolled(session.sessionId)
    };

    const ref = this.dialog.open(BookSessionDialog, {
      width: '580px',
      maxWidth: '95vw',
      data
    });

    ref.afterClosed().subscribe(
      (result: CreateBookingResult | undefined) => {
        if (!result) return;

        this.bookingMessage.set(
          result.status === 1
            ? `Member added to waitlist, position ${result.waitlistPosition ?? 'pending'}.`
            : 'Booking confirmed successfully.'
        );

        this.loadBookings(this.sessions());
      }
    );
  }

  openAddClass(): void {
    const ref = this.dialog.open(ClassFormDialog, {
      width: '760px',
      maxWidth: '95vw',
      autoFocus: false,
      data: {
        branches: this.branches(),
        trainers: this.trainers(),
        studios: this.studios(),
        selectedBranchId: this.selectedBranch()
      }
    });

    ref.afterClosed().subscribe(
      (result: CreateSessionDto | undefined) => {
        if (!result) return;

        this.classService.createSession(result).subscribe({
          next: () => {
            this.selectedBranch.set(result.branchId);
            this.selectedDate.set(result.sessionDate);
            this.bookingMessage.set('Class created successfully.');
            this.loadSessions();
          },
          error: error => {
            console.error('Failed to create session:', error);
            this.errorMessage.set(
              error.error?.message || 'Failed to schedule class.'
            );
          }
        });
      }
    );
  }
}

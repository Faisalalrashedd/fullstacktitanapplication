
import { Component, computed, inject, signal } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';

import { Autofocus } from '../../../../shared/directives/autofocus';
import {
  BranchDto,
  StudioDto,
  TrainerOptionDto,
  CreateSessionDto
} from '../../services/class';

interface ClassDialogData {
  branches: BranchDto[];
  trainers: TrainerOptionDto[];
  studios: StudioDto[];
  selectedBranchId: number;
}

@Component({
  selector: 'app-class-form-dialog',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    Autofocus
  ],
  templateUrl: './class-form-dialog.html',
  styleUrl: './class-form-dialog.css'
})
export class ClassFormDialog {
  private fb = inject(FormBuilder);
  private dialogRef = inject(MatDialogRef<ClassFormDialog>);
  data = inject<ClassDialogData>(MAT_DIALOG_DATA);

  selectedBranchId = signal(this.data.selectedBranchId);

  activeTrainers = this.data.trainers.filter(t => t.isActive);

  availableStudios = computed(() =>
    this.data.studios.filter(
      studio => studio.branchId === this.selectedBranchId()
    )
  );

  form = this.fb.group({
    className: ['', [
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(80)
    ]],
    branch: [
      this.data.selectedBranchId || null as number | null,
      Validators.required
    ],
    trainer: [null as number | null, Validators.required],
    studio: [null as number | null, Validators.required],
    date: ['', Validators.required],
    startTime: ['', Validators.required],
    capacity: [20, [
      Validators.required,
      Validators.min(1),
      Validators.max(100)
    ]],
    duration: [45, Validators.required],
    description: ['', Validators.maxLength(500)]
  });

  changeBranch(event: Event): void {
  const select = event.target as HTMLSelectElement;
  const branchId = Number(select.value);

  this.selectedBranchId.set(branchId);

  this.form.patchValue({
    branch: branchId || null,
    studio: null
  });
}

  setDuration(minutes: number): void {
    this.form.patchValue({ duration: minutes });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const v = this.form.getRawValue();

    const studio = this.data.studios.find(
      s => s.studioId === Number(v.studio)
    );

    if (studio && Number(v.capacity) > studio.capacity) {
      this.form.controls.capacity.setErrors({ capacityExceeded: true });
      return;
    }

    const start = new Date(`${v.date}T${v.startTime}`);

    if (Number.isNaN(start.getTime()) || start <= new Date()) {
      this.form.controls.startTime.setErrors({ invalidTime: true });
      return;
    }

    const time = v.startTime || '';

    const request: CreateSessionDto = {
      className: v.className?.trim() || '',
      branchId: Number(v.branch),
      trainerId: Number(v.trainer),
      studioId: Number(v.studio),
      sessionDate: v.date || '',
      startTime: time.length === 5 ? `${time}:00` : time,
      capacityLimit: Number(v.capacity),
      durationInMinutes: Number(v.duration),
      description: v.description?.trim() || null
    };

    this.dialogRef.close(request);
  }
}

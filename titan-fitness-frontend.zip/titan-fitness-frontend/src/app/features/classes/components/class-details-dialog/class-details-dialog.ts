
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogModule
} from '@angular/material/dialog';
import { finalize, forkJoin } from 'rxjs';

import {
  ClassService,
  ClassSessionDto,
  BranchDto,
  StudioDto,
  TrainerOptionDto,
  CreateSessionDto
} from '../../services/class';

export interface ClassDetailsData {
  sessionId: number;
}

@Component({
  selector: 'app-class-details-dialog',
  standalone: true,
  imports: [ReactiveFormsModule, MatDialogModule],
  templateUrl: './class-details-dialog.html',
  styleUrl: './class-details-dialog.css'
})
export class ClassDetailsDialog implements OnInit {
  private fb = inject(FormBuilder);
  private classService = inject(ClassService);
  private dialogRef = inject(MatDialogRef<ClassDetailsDialog>);

  data = inject<ClassDetailsData>(MAT_DIALOG_DATA);

  session = signal<ClassSessionDto | null>(null);
  branches = signal<BranchDto[]>([]);
  trainers = signal<TrainerOptionDto[]>([]);
  studios = signal<StudioDto[]>([]);

  mode = signal<'view' | 'edit'>('view');
  loading = signal(true);
  saving = signal(false);
  errorMessage = signal('');

  form = this.fb.group({
    className: ['', [Validators.required, Validators.maxLength(100)]],
    branchId: [0, [Validators.required, Validators.min(1)]],
    studioId: [0, [Validators.required, Validators.min(1)]],
    trainerId: [0, [Validators.required, Validators.min(1)]],
    sessionDate: ['', Validators.required],
    startTime: ['', Validators.required],
    durationInMinutes: [60, [Validators.required, Validators.min(1)]],
    capacityLimit: [20, [Validators.required, Validators.min(1)]],
    description: ['']
  });

  ngOnInit(): void {
    forkJoin({
      session: this.classService.getSession(this.data.sessionId),
      branches: this.classService.getBranches(),
      trainers: this.classService.getTrainers()
    }).subscribe({
      next: ({ session, branches, trainers }) => {
        this.session.set(session);
        this.branches.set(branches);
        this.trainers.set(trainers);

        this.form.patchValue({
          className: session.className,
          branchId: session.branchId,
          studioId: session.studioId,
          trainerId: session.trainerId,
          sessionDate: session.sessionDate.slice(0, 10),
          startTime: session.startTime.slice(0, 5),
          durationInMinutes: session.durationInMinutes,
          capacityLimit: session.capacityLimit,
          description: session.description || ''
        });

        this.loadStudios(session.branchId);
        this.loading.set(false);
      },
      error: error => {
        console.error('Unable to load class:', error);
        this.errorMessage.set('Unable to load class details.');
        this.loading.set(false);
      }
    });
  }

  loadStudios(branchId: number): void {
    if (!branchId) {
      this.studios.set([]);
      return;
    }

    this.classService.getStudios(branchId).subscribe({
      next: studios => this.studios.set(studios),
      error: () => this.errorMessage.set('Unable to load studios.')
    });
  }

  changeBranch(event: Event): void {
    const branchId = Number(
      (event.target as HTMLSelectElement).value
    );

    this.form.patchValue({
      branchId,
      studioId: 0
    });

    this.loadStudios(branchId);
  }

  startEdit(): void {
    this.errorMessage.set('');
    this.mode.set('edit');
  }

  cancelEdit(): void {
    const session = this.session();

    if (!session) return;

    this.form.patchValue({
      className: session.className,
      branchId: session.branchId,
      studioId: session.studioId,
      trainerId: session.trainerId,
      sessionDate: session.sessionDate.slice(0, 10),
      startTime: session.startTime.slice(0, 5),
      durationInMinutes: session.durationInMinutes,
      capacityLimit: session.capacityLimit,
      description: session.description || ''
    });

    this.loadStudios(session.branchId);
    this.errorMessage.set('');
    this.mode.set('view');
  }

  save(): void {
    if (this.form.invalid || this.saving()) {
      this.form.markAllAsTouched();
      return;
    }

    const session = this.session();
    if (!session) return;

    const value = this.form.getRawValue();

    const request: CreateSessionDto = {
      className: value.className?.trim() || '',
      branchId: Number(value.branchId),
      studioId: Number(value.studioId),
      trainerId: Number(value.trainerId),
      sessionDate: value.sessionDate || '',
      startTime: value.startTime || '',
      durationInMinutes: Number(value.durationInMinutes),
      capacityLimit: Number(value.capacityLimit),
      description: value.description?.trim() || null
    };

    this.saving.set(true);
    this.errorMessage.set('');

    this.classService.updateSession(
      session.sessionId,
      request
    ).pipe(
      finalize(() => this.saving.set(false))
    ).subscribe({
      next: () => {
        this.dialogRef.close({ updated: true });
      },
      error: error => {
        console.error('Class update failed:', error);
        this.errorMessage.set(
          error.error?.message || 'Unable to update class.'
        );
      }
    });
  }

  cancelClass(): void {
    const session = this.session();

    if (!session || this.saving()) return;

    const confirmed = window.confirm(
      `Cancel "${session.className}"? This will mark the class as cancelled.`
    );

    if (!confirmed) return;

    this.saving.set(true);
    this.errorMessage.set('');

    this.classService.cancelSession(session.sessionId).pipe(
      finalize(() => this.saving.set(false))
    ).subscribe({
      next: () => {
        this.dialogRef.close({ cancelled: true });
      },
      error: error => {
        console.error('Class cancellation failed:', error);
        this.errorMessage.set(
          error.error?.message || 'Unable to cancel class.'
        );
      }
    });
  }

  close(): void {
    this.dialogRef.close();
  }

  statusText(status: number): string {
    switch (status) {
      case 0: return 'Upcoming';
      case 1: return 'In Progress';
      case 2: return 'Completed';
      case 3: return 'Cancelled';
      default: return 'Unknown';
    }
  }
}

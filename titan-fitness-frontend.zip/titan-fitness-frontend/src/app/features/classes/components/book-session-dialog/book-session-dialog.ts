
import { Component, inject, OnInit, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';

import { MemberService, MemberDto } from '../../../members/services/member';
import { BookingService } from '../../services/booking';

export interface BookingDialogData {
  sessionId: number;
  className: string;
  trainer: string;
  studio: string;
  date: string;
  time: string;
  capacity: number;
  enrolled: number;
}

@Component({
  selector: 'app-book-session-dialog',
  standalone: true,
  imports: [ReactiveFormsModule, MatDialogModule],
  templateUrl: './book-session-dialog.html',
  styleUrl: './book-session-dialog.css'
})
export class BookSessionDialog implements OnInit {
  private fb = inject(FormBuilder);
  private memberService = inject(MemberService);
  private bookingService = inject(BookingService);
  private dialogRef = inject(MatDialogRef<BookSessionDialog>);

  data = inject<BookingDialogData>(MAT_DIALOG_DATA);

  members = signal<MemberDto[]>([]);
  search = signal('');
  loading = signal(true);
  saving = signal(false);
  errorMessage = signal('');
  successMessage = signal('');

  form = this.fb.group({
    memberId: [null as number | null, Validators.required],
    notesForTrainer: ['', Validators.maxLength(500)]
  });

  get filteredMembers(): MemberDto[] {
    const term = this.search().trim().toLowerCase();

    return this.members().filter(member =>
      member.fullName.toLowerCase().includes(term) ||
      member.membershipNumber.toLowerCase().includes(term)
    );
  }

  ngOnInit(): void {
    this.memberService.getMembers().subscribe({
      next: members => {
        this.members.set(members);
        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load members:', error);
        this.errorMessage.set('Unable to load members.');
        this.loading.set(false);
      }
    });
  }

  updateSearch(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.search.set(input.value);
  }

  selectMember(id: number): void {
    this.form.patchValue({ memberId: id });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  submit(): void {
    if (this.form.invalid || this.saving()) {
      this.form.markAllAsTouched();
      return;
    }

    const memberId = this.form.value.memberId;

    if (!memberId) return;

    this.saving.set(true);
    this.errorMessage.set('');

    this.bookingService.createBooking(this.data.sessionId, {
      memberId,
      notesForTrainer: this.form.value.notesForTrainer?.trim() || null
    }).subscribe({
      next: result => {
        this.saving.set(false);
        this.dialogRef.close(result);
      },
      error: error => {
        console.error('Booking failed:', error);

        const response = error.error;
        this.errorMessage.set(
          typeof response?.message === 'string'
            ? response.message
            : typeof response?.Message === 'string'
              ? response.Message
              : 'Booking failed. Check membership eligibility and try again.'
        );

        this.saving.set(false);
      }
    });
  }
}


import { Component, computed, signal, inject, OnInit } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { RouterLink } from '@angular/router';

import { Paginator } from '../../../../shared/components/paginator/paginator';
import { HighlightPipe } from '../../../../shared/pipes/highlight-pipe';
import { FreezeAllowancePipe } from '../../../../shared/pipes/freeze-allowance-pipe';
import { PlanService } from '../../services/plan';

interface Plan {
  id: number;
  name: string;
  price: number;
  duration: number;
  freezeDays: number;
  freezes: number;
  guestPasses: number;
  access: string;
  status: 'Published' | 'Retired';
}

@Component({
  selector: 'app-plan-catalogue',
  standalone: true,
  imports: [
    RouterLink,
    CurrencyPipe,
    Paginator,
    HighlightPipe,
    FreezeAllowancePipe
  ],
  templateUrl: './plan-catalogue.html',
  styleUrl: './plan-catalogue.css'
})
export class PlanCatalogue implements OnInit {
  private planService = inject(PlanService);

  searchTerm = signal('');
  currentPage = signal(1);
  pageSize = 4;
  openMenuId = signal<number | null>(null);

  loading = signal(false);
  errorMessage = signal('');

  plans = signal<Plan[]>([]);

  filteredPlans = computed(() => {
    const search = this.searchTerm().trim().toLowerCase();

    if (!search) {
      return this.plans();
    }

    return this.plans().filter(plan =>
      plan.name.toLowerCase().includes(search) ||
      plan.access.toLowerCase().includes(search)
    );
  });

  totalPages = computed(() =>
    Math.max(
      1,
      Math.ceil(this.filteredPlans().length / this.pageSize)
    )
  );

  pagedPlans = computed(() => {
    const start = (this.currentPage() - 1) * this.pageSize;

    return this.filteredPlans().slice(
      start,
      start + this.pageSize
    );
  });

  ngOnInit(): void {
    this.loadPlans();
  }

  loadPlans(): void {
    this.loading.set(true);
    this.errorMessage.set('');

    this.planService.getPlans().subscribe({
      next: plans => {
        const mappedPlans: Plan[] = plans.map(plan => ({
          id: plan.planId,
          name: plan.planName,
          price: plan.price,
          duration: plan.durationInMonths,
          freezeDays: plan.maximumFreezeDays,
          freezes: plan.maximumNumberOfFreezes,
          guestPasses: plan.guestPassQuota,
          access: Number(plan.accessScope) === 1
            ? 'All branches'
            : 'Home branch only',
          status: plan.isPublished
            ? 'Published'
            : 'Retired'
        }));

        this.plans.set(mappedPlans);
        this.currentPage.set(1);
        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load plans:', error);
        this.errorMessage.set('Failed to load plans.');
        this.loading.set(false);
      }
    });
  }

  updateSearch(event: Event): void {
    const input = event.target as HTMLInputElement;

    this.searchTerm.set(input.value);
    this.currentPage.set(1);
    this.openMenuId.set(null);
  }

  changePage(page: number): void {
    if (page < 1 || page > this.totalPages()) {
      return;
    }

    this.currentPage.set(page);
    this.openMenuId.set(null);
  }

  toggleMenu(id: number): void {
    this.openMenuId.update(current =>
      current === id ? null : id
    );
  }
}

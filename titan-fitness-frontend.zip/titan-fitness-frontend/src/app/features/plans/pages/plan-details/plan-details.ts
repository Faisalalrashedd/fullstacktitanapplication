
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { PlanService, SavePlanDto } from '../../services/plan';

type PlanMode = 'add' | 'view' | 'edit';

@Component({
  selector: 'app-plan-details',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './plan-details.html',
  styleUrl: './plan-details.css'
})
export class PlanDetails implements OnInit {
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private planService = inject(PlanService);

  mode = signal<PlanMode>('view');
  planId = signal<number | null>(null);
  planName = signal('Plan Details');

  loading = signal(false);
  saving = signal(false);
  errorMessage = signal('');

  isAddMode = computed(() => this.mode() === 'add');
  isViewMode = computed(() => this.mode() === 'view');
  isEditMode = computed(() => this.mode() === 'edit');

  pageTitle = computed(() =>
    this.isAddMode() ? 'New Plan' : this.planName()
  );

  modeText = computed(() => {
    if (this.isAddMode()) return 'Add mode';
    if (this.isEditMode()) return 'Update mode';
    return 'View mode';
  });

  form = this.fb.group({
    name: ['', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(50)
    ]],
    price: [null as number | null, [
      Validators.required,
      Validators.min(0)
    ]],
    duration: [null as number | null, [
      Validators.required,
      Validators.min(1),
      Validators.max(36),
      Validators.pattern(/^\d+$/)
    ]],
    isPublished: [false],
    freezeDays: [0, [
      Validators.min(0),
      Validators.pattern(/^\d+$/)
    ]],
    maxFreezes: [0, [
      Validators.min(0),
      Validators.pattern(/^\d+$/)
    ]],
    guestPasses: [0, [
      Validators.min(0),
      Validators.pattern(/^\d+$/)
    ]],
    accessScope: ['']
  });

  ngOnInit(): void {
    const url = this.router.url;

    if (url === '/plans/new') {
      this.mode.set('add');
      this.form.reset({
        name: '',
        price: null,
        duration: null,
        isPublished: false,
        freezeDays: 0,
        maxFreezes: 0,
        guestPasses: 0,
        accessScope: ''
      });
      return;
    }

    const id = Number(this.route.snapshot.paramMap.get('id'));

    if (!Number.isInteger(id) || id <= 0) {
      this.errorMessage.set('Invalid plan ID.');
      return;
    }

    this.planId.set(id);
    this.mode.set(url.endsWith('/edit') ? 'edit' : 'view');

    this.loadPlan(id);
  }

  loadPlan(id: number): void {
    this.loading.set(true);
    this.errorMessage.set('');

    this.planService.getPlan(id).subscribe({
      next: plan => {
        this.planName.set(plan.planName);

        this.form.patchValue({
          name: plan.planName,
          price: plan.price,
          duration: plan.durationInMonths,
          isPublished: plan.isPublished,
          freezeDays: plan.maximumFreezeDays,
          maxFreezes: plan.maximumNumberOfFreezes,
          guestPasses: plan.guestPassQuota,
          accessScope: Number(plan.accessScope) === 1
            ? 'all'
            : 'home'
        });

        if (this.isViewMode()) {
          this.form.disable();
        } else {
          this.form.enable();
        }

        this.loading.set(false);
      },
      error: error => {
        console.error('Failed to load plan:', error);
        this.errorMessage.set(
          error.status === 404
            ? 'Plan not found.'
            : 'Failed to load plan.'
        );
        this.loading.set(false);
      }
    });
  }

  editPlan(): void {
    const id = this.planId();

    if (id !== null) {
      this.router.navigate(['/plans', id, 'edit']);
    }
  }

  cancel(): void {
    const id = this.planId();

    if (this.isEditMode() && id !== null) {
      this.router.navigate(['/plans', id]);
    } else {
      this.router.navigate(['/plans']);
    }
  }

  save(): void {
    if (this.form.invalid || this.saving()) {
      this.form.markAllAsTouched();
      return;
    }

    const values = this.form.getRawValue();

    if (
      Number(values.freezeDays) === 0 &&
      Number(values.maxFreezes) > 0
    ) {
      this.errorMessage.set(
        'Maximum freezes must be 0 when freeze days is 0.'
      );
      alert(this.errorMessage());
      return;
    }

    const request: SavePlanDto = {
      planName: values.name?.trim() || '',
      price: Number(values.price),
      durationInMonths: Number(values.duration),
      maximumFreezeDays: Number(values.freezeDays ?? 0),
      maximumNumberOfFreezes: Number(values.maxFreezes ?? 0),
      guestPassQuota: Number(values.guestPasses ?? 0),
      accessScope: values.accessScope === 'all' ? 1 : 0,
      isPublished: values.isPublished ?? false
    };

    this.saving.set(true);
    this.errorMessage.set('');

    if (this.isAddMode()) {
      this.planService.addPlan(request).subscribe({
        next: result => {
          this.saving.set(false);
          alert('Plan created successfully');

          if (result.planId) {
            this.router.navigate(['/plans', result.planId]);
          } else {
            this.router.navigate(['/plans']);
          }
        },
        error: error => {
          console.error('Failed to create plan:', error);
          this.errorMessage.set('Failed to create plan.');
          this.saving.set(false);
        }
      });

      return;
    }

    const id = this.planId();

    if (id === null) {
      this.saving.set(false);
      return;
    }

    this.planService.updatePlan(id, request).subscribe({
      next: () => {
        this.saving.set(false);
        alert('Plan updated successfully');
        this.router.navigate(['/plans', id]);
      },
      error: error => {
        console.error('Failed to update plan:', error);
        this.errorMessage.set('Failed to update plan.');
        this.saving.set(false);
      }
    });
  }
}

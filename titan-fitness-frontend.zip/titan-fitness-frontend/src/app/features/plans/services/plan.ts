
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_BASE_URL } from '../../../core/api.config';

export interface PlanDto {
  planId: number;
  planName: string;
  price: number;
  durationInMonths: number;
  maximumFreezeDays: number;
  maximumNumberOfFreezes: number;
  guestPassQuota: number;
  accessScope: number;
  isPublished: boolean;
}

export type SavePlanDto = Omit<PlanDto, 'planId'>;

export interface PlanSaveResult {
  planId?: number;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class PlanService {
  private http = inject(HttpClient);
  private apiUrl = `${API_BASE_URL}/Plans`;

  getPlans(): Observable<PlanDto[]> {
    return this.http.get<PlanDto[]>(this.apiUrl);
  }

  getPlan(id: number): Observable<PlanDto> {
    return this.http.get<PlanDto>(`${this.apiUrl}/${id}`);
  }

  addPlan(plan: SavePlanDto): Observable<PlanSaveResult> {
    return this.http.post<PlanSaveResult>(this.apiUrl, plan);
  }

  updatePlan(
    id: number,
    plan: SavePlanDto
  ): Observable<PlanSaveResult> {
    return this.http.put<PlanSaveResult>(
      `${this.apiUrl}/${id}`,
      plan
    );
  }
}

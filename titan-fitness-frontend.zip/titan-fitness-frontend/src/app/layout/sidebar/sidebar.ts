
import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { CheckInDialog } from '../../features/members/components/check-in-dialog/check-in-dialog';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar {
  private dialog = inject(MatDialog);

  openCheckIn(): void {
    this.dialog.open(CheckInDialog, {
      width: '580px',
      maxWidth: '95vw',
      autoFocus: false
    });
  }
}
